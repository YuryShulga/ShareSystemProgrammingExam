﻿namespace WordsFinderApp
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.labelLoadWord = new System.Windows.Forms.Label();
            this.progressBarLoadWords = new System.Windows.Forms.ProgressBar();
            this.buttonCearList = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonLoadFromFile = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonAddWord = new System.Windows.Forms.Button();
            this.textBoxNewWord = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.labelUpdatedFilesCount = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.labelCopiedFilesCount = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonChangeFolder = new System.Windows.Forms.Button();
            this.textBoxFolderPath = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelFilesCount = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.labelProcessName = new System.Windows.Forms.Label();
            this.buttonStartPauseFind = new System.Windows.Forms.Button();
            this.buttonStopFind = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(815, 440);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.labelLoadWord);
            this.tabPage1.Controls.Add(this.progressBarLoadWords);
            this.tabPage1.Controls.Add(this.buttonCearList);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.buttonLoadFromFile);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.buttonAddWord);
            this.tabPage1.Controls.Add(this.textBoxNewWord);
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Size = new System.Drawing.Size(807, 407);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Слова для поиска";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.listBox2);
            this.tabPage2.Controls.Add(this.progressBar3);
            this.tabPage2.Controls.Add(this.labelUpdatedFilesCount);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.labelCopiedFilesCount);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.buttonChangeFolder);
            this.tabPage2.Controls.Add(this.textBoxFolderPath);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.progressBar2);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.labelFilesCount);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.progressBar1);
            this.tabPage2.Controls.Add(this.labelProcessName);
            this.tabPage2.Controls.Add(this.buttonStartPauseFind);
            this.tabPage2.Controls.Add(this.buttonStopFind);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage2.Size = new System.Drawing.Size(807, 407);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Поиск/Замена";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // labelLoadWord
            // 
            this.labelLoadWord.AutoSize = true;
            this.labelLoadWord.Location = new System.Drawing.Point(301, 40);
            this.labelLoadWord.Name = "labelLoadWord";
            this.labelLoadWord.Size = new System.Drawing.Size(138, 20);
            this.labelLoadWord.TabIndex = 30;
            this.labelLoadWord.Text = "слова загружены";
            // 
            // progressBarLoadWords
            // 
            this.progressBarLoadWords.Location = new System.Drawing.Point(230, 43);
            this.progressBarLoadWords.Name = "progressBarLoadWords";
            this.progressBarLoadWords.Size = new System.Drawing.Size(275, 14);
            this.progressBarLoadWords.TabIndex = 29;
            // 
            // buttonCearList
            // 
            this.buttonCearList.Location = new System.Drawing.Point(230, 243);
            this.buttonCearList.Name = "buttonCearList";
            this.buttonCearList.Size = new System.Drawing.Size(275, 35);
            this.buttonCearList.TabIndex = 28;
            this.buttonCearList.Text = "очистить список слов";
            this.buttonCearList.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(226, 207);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(279, 20);
            this.label3.TabIndex = 27;
            this.label3.Text = "------------------------------------------------------";
            // 
            // buttonLoadFromFile
            // 
            this.buttonLoadFromFile.Location = new System.Drawing.Point(230, 8);
            this.buttonLoadFromFile.Name = "buttonLoadFromFile";
            this.buttonLoadFromFile.Size = new System.Drawing.Size(275, 29);
            this.buttonLoadFromFile.TabIndex = 26;
            this.buttonLoadFromFile.Text = "загрузить из файла";
            this.buttonLoadFromFile.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(226, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(279, 20);
            this.label2.TabIndex = 25;
            this.label2.Text = "------------------------------------------------------";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(320, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 20);
            this.label1.TabIndex = 24;
            this.label1.Text = "новое слово";
            // 
            // buttonAddWord
            // 
            this.buttonAddWord.Location = new System.Drawing.Point(230, 155);
            this.buttonAddWord.Name = "buttonAddWord";
            this.buttonAddWord.Size = new System.Drawing.Size(275, 32);
            this.buttonAddWord.TabIndex = 23;
            this.buttonAddWord.Text = "добавить";
            this.buttonAddWord.UseVisualStyleBackColor = true;
            // 
            // textBoxNewWord
            // 
            this.textBoxNewWord.Location = new System.Drawing.Point(240, 113);
            this.textBoxNewWord.Name = "textBoxNewWord";
            this.textBoxNewWord.Size = new System.Drawing.Size(265, 26);
            this.textBoxNewWord.TabIndex = 22;
            // 
            // listBox1
            // 
            this.listBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(7, 8);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(213, 344);
            this.listBox1.TabIndex = 21;
            // 
            // progressBar3
            // 
            this.progressBar3.Location = new System.Drawing.Point(12, 351);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(393, 27);
            this.progressBar3.TabIndex = 40;
            // 
            // labelUpdatedFilesCount
            // 
            this.labelUpdatedFilesCount.AutoSize = true;
            this.labelUpdatedFilesCount.Location = new System.Drawing.Point(174, 328);
            this.labelUpdatedFilesCount.Name = "labelUpdatedFilesCount";
            this.labelUpdatedFilesCount.Size = new System.Drawing.Size(18, 20);
            this.labelUpdatedFilesCount.TabIndex = 39;
            this.labelUpdatedFilesCount.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 328);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(188, 20);
            this.label12.TabIndex = 38;
            this.label12.Text = "Замена слов на ******* - ";
            // 
            // labelCopiedFilesCount
            // 
            this.labelCopiedFilesCount.AutoSize = true;
            this.labelCopiedFilesCount.Location = new System.Drawing.Point(188, 221);
            this.labelCopiedFilesCount.Name = "labelCopiedFilesCount";
            this.labelCopiedFilesCount.Size = new System.Drawing.Size(18, 20);
            this.labelCopiedFilesCount.TabIndex = 37;
            this.labelCopiedFilesCount.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 308);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(399, 20);
            this.label11.TabIndex = 36;
            this.label11.Text = "------------------------------------------------------------------------------";
            // 
            // buttonChangeFolder
            // 
            this.buttonChangeFolder.Location = new System.Drawing.Point(283, 242);
            this.buttonChangeFolder.Name = "buttonChangeFolder";
            this.buttonChangeFolder.Size = new System.Drawing.Size(118, 30);
            this.buttonChangeFolder.TabIndex = 35;
            this.buttonChangeFolder.Text = "Изменить";
            this.buttonChangeFolder.UseVisualStyleBackColor = true;
            // 
            // textBoxFolderPath
            // 
            this.textBoxFolderPath.Location = new System.Drawing.Point(54, 244);
            this.textBoxFolderPath.Name = "textBoxFolderPath";
            this.textBoxFolderPath.ReadOnly = true;
            this.textBoxFolderPath.Size = new System.Drawing.Size(223, 26);
            this.textBoxFolderPath.TabIndex = 34;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 245);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 20);
            this.label10.TabIndex = 33;
            this.label10.Text = "Путь :";
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(14, 278);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(393, 27);
            this.progressBar2.TabIndex = 32;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 221);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(187, 20);
            this.label9.TabIndex = 31;
            this.label9.Text = "Копирование файлов - ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 201);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(399, 20);
            this.label8.TabIndex = 30;
            this.label8.Text = "------------------------------------------------------------------------------";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 148);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 20);
            this.label7.TabIndex = 29;
            this.label7.Text = "label7";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(399, 20);
            this.label6.TabIndex = 28;
            this.label6.Text = "------------------------------------------------------------------------------";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(399, 20);
            this.label5.TabIndex = 27;
            this.label5.Text = "------------------------------------------------------------------------------";
            // 
            // labelFilesCount
            // 
            this.labelFilesCount.AutoSize = true;
            this.labelFilesCount.Location = new System.Drawing.Point(133, 88);
            this.labelFilesCount.Name = "labelFilesCount";
            this.labelFilesCount.Size = new System.Drawing.Size(18, 20);
            this.labelFilesCount.TabIndex = 26;
            this.labelFilesCount.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 20);
            this.label4.TabIndex = 25;
            this.label4.Text = "Поиск файлов - ";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 171);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(393, 27);
            this.progressBar1.TabIndex = 24;
            // 
            // labelProcessName
            // 
            this.labelProcessName.AutoSize = true;
            this.labelProcessName.Location = new System.Drawing.Point(8, 128);
            this.labelProcessName.Name = "labelProcessName";
            this.labelProcessName.Size = new System.Drawing.Size(320, 20);
            this.labelProcessName.TabIndex = 23;
            this.labelProcessName.Text = "Поиск файлов с запрещенными словами";
            // 
            // buttonStartPauseFind
            // 
            this.buttonStartPauseFind.Location = new System.Drawing.Point(8, 8);
            this.buttonStartPauseFind.Name = "buttonStartPauseFind";
            this.buttonStartPauseFind.Size = new System.Drawing.Size(184, 52);
            this.buttonStartPauseFind.TabIndex = 21;
            this.buttonStartPauseFind.Text = "Старт ";
            this.buttonStartPauseFind.UseVisualStyleBackColor = true;
            // 
            // buttonStopFind
            // 
            this.buttonStopFind.Location = new System.Drawing.Point(223, 8);
            this.buttonStopFind.Name = "buttonStopFind";
            this.buttonStopFind.Size = new System.Drawing.Size(184, 52);
            this.buttonStopFind.TabIndex = 22;
            this.buttonStopFind.Text = "Стоп";
            this.buttonStopFind.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            this.listBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.HorizontalScrollbar = true;
            this.listBox2.ItemHeight = 20;
            this.listBox2.Location = new System.Drawing.Point(470, 5);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(333, 397);
            this.listBox2.TabIndex = 41;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 440);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FormMain";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label labelLoadWord;
        private System.Windows.Forms.ProgressBar progressBarLoadWords;
        private System.Windows.Forms.Button buttonCearList;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonLoadFromFile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonAddWord;
        private System.Windows.Forms.TextBox textBoxNewWord;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.Label labelUpdatedFilesCount;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label labelCopiedFilesCount;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonChangeFolder;
        private System.Windows.Forms.TextBox textBoxFolderPath;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelFilesCount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label labelProcessName;
        private System.Windows.Forms.Button buttonStartPauseFind;
        private System.Windows.Forms.Button buttonStopFind;
        private System.Windows.Forms.ListBox listBox2;
    }
}

