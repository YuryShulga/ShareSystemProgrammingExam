﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WordsFinderLibrary;

namespace WordsFinderApp
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
            WordsFinder 
        }

        private void buttonChangeFolder_Click(object sender, EventArgs e)
        {

        }

        private void buttonStartPauseFind_Click(object sender, EventArgs e)
        {

        }

        private void buttonStopFind_Click(object sender, EventArgs e)
        {

        }
    }
}
