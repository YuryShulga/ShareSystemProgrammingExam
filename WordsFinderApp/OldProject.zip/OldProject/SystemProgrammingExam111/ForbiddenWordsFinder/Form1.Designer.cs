﻿namespace ForbiddenWordsFinder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageWords = new System.Windows.Forms.TabPage();
            this.buttonCearList = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonLoadFromFile = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonAddWord = new System.Windows.Forms.Button();
            this.textBoxNewWord = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPageFindWords = new System.Windows.Forms.TabPage();
            this.labelCopiedFilesCount = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonChangeFolder = new System.Windows.Forms.Button();
            this.textBoxFolderPath = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelFilesCount = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.labelProcessName = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.buttonStartPauseFind = new System.Windows.Forms.Button();
            this.buttonStopFind = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.labelUpdatedFilesCount = new System.Windows.Forms.Label();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.progressBarLoadWords = new System.Windows.Forms.ProgressBar();
            this.labelLoadWord = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPageWords.SuspendLayout();
            this.tabPageFindWords.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageWords);
            this.tabControl1.Controls.Add(this.tabPageFindWords);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(757, 446);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPageWords
            // 
            this.tabPageWords.Controls.Add(this.labelLoadWord);
            this.tabPageWords.Controls.Add(this.progressBarLoadWords);
            this.tabPageWords.Controls.Add(this.buttonCearList);
            this.tabPageWords.Controls.Add(this.label3);
            this.tabPageWords.Controls.Add(this.buttonLoadFromFile);
            this.tabPageWords.Controls.Add(this.label2);
            this.tabPageWords.Controls.Add(this.label1);
            this.tabPageWords.Controls.Add(this.buttonAddWord);
            this.tabPageWords.Controls.Add(this.textBoxNewWord);
            this.tabPageWords.Controls.Add(this.listBox1);
            this.tabPageWords.Location = new System.Drawing.Point(4, 29);
            this.tabPageWords.Name = "tabPageWords";
            this.tabPageWords.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageWords.Size = new System.Drawing.Size(749, 413);
            this.tabPageWords.TabIndex = 0;
            this.tabPageWords.Text = "Слова";
            this.tabPageWords.UseVisualStyleBackColor = true;
            // 
            // buttonCearList
            // 
            this.buttonCearList.Location = new System.Drawing.Point(231, 241);
            this.buttonCearList.Name = "buttonCearList";
            this.buttonCearList.Size = new System.Drawing.Size(275, 35);
            this.buttonCearList.TabIndex = 8;
            this.buttonCearList.Text = "очистить список слов";
            this.buttonCearList.UseVisualStyleBackColor = true;
            this.buttonCearList.Click += new System.EventHandler(this.buttonCearList_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(227, 205);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(279, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "------------------------------------------------------";
            // 
            // buttonLoadFromFile
            // 
            this.buttonLoadFromFile.Location = new System.Drawing.Point(231, 6);
            this.buttonLoadFromFile.Name = "buttonLoadFromFile";
            this.buttonLoadFromFile.Size = new System.Drawing.Size(275, 29);
            this.buttonLoadFromFile.TabIndex = 6;
            this.buttonLoadFromFile.Text = "загрузить из файла";
            this.buttonLoadFromFile.UseVisualStyleBackColor = true;
            this.buttonLoadFromFile.Click += new System.EventHandler(this.buttonLoadFromFile_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(227, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(279, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "------------------------------------------------------";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(321, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "новое слово";
            // 
            // buttonAddWord
            // 
            this.buttonAddWord.Location = new System.Drawing.Point(231, 153);
            this.buttonAddWord.Name = "buttonAddWord";
            this.buttonAddWord.Size = new System.Drawing.Size(275, 32);
            this.buttonAddWord.TabIndex = 3;
            this.buttonAddWord.Text = "добавить";
            this.buttonAddWord.UseVisualStyleBackColor = true;
            this.buttonAddWord.Click += new System.EventHandler(this.buttonAddWord_Click);
            // 
            // textBoxNewWord
            // 
            this.textBoxNewWord.Location = new System.Drawing.Point(241, 111);
            this.textBoxNewWord.Name = "textBoxNewWord";
            this.textBoxNewWord.Size = new System.Drawing.Size(265, 26);
            this.textBoxNewWord.TabIndex = 2;
            // 
            // listBox1
            // 
            this.listBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(8, 6);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(213, 344);
            this.listBox1.TabIndex = 0;
            // 
            // tabPageFindWords
            // 
            this.tabPageFindWords.Controls.Add(this.progressBar3);
            this.tabPageFindWords.Controls.Add(this.labelUpdatedFilesCount);
            this.tabPageFindWords.Controls.Add(this.label12);
            this.tabPageFindWords.Controls.Add(this.labelCopiedFilesCount);
            this.tabPageFindWords.Controls.Add(this.label11);
            this.tabPageFindWords.Controls.Add(this.buttonChangeFolder);
            this.tabPageFindWords.Controls.Add(this.textBoxFolderPath);
            this.tabPageFindWords.Controls.Add(this.label10);
            this.tabPageFindWords.Controls.Add(this.progressBar2);
            this.tabPageFindWords.Controls.Add(this.label9);
            this.tabPageFindWords.Controls.Add(this.label8);
            this.tabPageFindWords.Controls.Add(this.label7);
            this.tabPageFindWords.Controls.Add(this.label6);
            this.tabPageFindWords.Controls.Add(this.label5);
            this.tabPageFindWords.Controls.Add(this.labelFilesCount);
            this.tabPageFindWords.Controls.Add(this.label4);
            this.tabPageFindWords.Controls.Add(this.progressBar1);
            this.tabPageFindWords.Controls.Add(this.labelProcessName);
            this.tabPageFindWords.Controls.Add(this.listBox2);
            this.tabPageFindWords.Controls.Add(this.buttonStartPauseFind);
            this.tabPageFindWords.Controls.Add(this.buttonStopFind);
            this.tabPageFindWords.Location = new System.Drawing.Point(4, 29);
            this.tabPageFindWords.Name = "tabPageFindWords";
            this.tabPageFindWords.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFindWords.Size = new System.Drawing.Size(749, 413);
            this.tabPageFindWords.TabIndex = 1;
            this.tabPageFindWords.Text = "Поиск";
            this.tabPageFindWords.UseVisualStyleBackColor = true;
            // 
            // labelCopiedFilesCount
            // 
            this.labelCopiedFilesCount.AutoSize = true;
            this.labelCopiedFilesCount.Location = new System.Drawing.Point(188, 219);
            this.labelCopiedFilesCount.Name = "labelCopiedFilesCount";
            this.labelCopiedFilesCount.Size = new System.Drawing.Size(18, 20);
            this.labelCopiedFilesCount.TabIndex = 17;
            this.labelCopiedFilesCount.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 306);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(399, 20);
            this.label11.TabIndex = 16;
            this.label11.Text = "------------------------------------------------------------------------------";
            // 
            // buttonChangeFolder
            // 
            this.buttonChangeFolder.Location = new System.Drawing.Point(283, 240);
            this.buttonChangeFolder.Name = "buttonChangeFolder";
            this.buttonChangeFolder.Size = new System.Drawing.Size(118, 30);
            this.buttonChangeFolder.TabIndex = 15;
            this.buttonChangeFolder.Text = "Изменить";
            this.buttonChangeFolder.UseVisualStyleBackColor = true;
            this.buttonChangeFolder.Click += new System.EventHandler(this.buttonChangeFolder_Click);
            // 
            // textBoxFolderPath
            // 
            this.textBoxFolderPath.Location = new System.Drawing.Point(54, 242);
            this.textBoxFolderPath.Name = "textBoxFolderPath";
            this.textBoxFolderPath.ReadOnly = true;
            this.textBoxFolderPath.Size = new System.Drawing.Size(223, 26);
            this.textBoxFolderPath.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 243);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 20);
            this.label10.TabIndex = 13;
            this.label10.Text = "Путь :";
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(14, 276);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(393, 27);
            this.progressBar2.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 219);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(187, 20);
            this.label9.TabIndex = 11;
            this.label9.Text = "Копирование файлов - ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 199);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(399, 20);
            this.label8.TabIndex = 10;
            this.label8.Text = "------------------------------------------------------------------------------";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 146);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 20);
            this.label7.TabIndex = 9;
            this.label7.Text = "label7";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(399, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "------------------------------------------------------------------------------";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(399, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "------------------------------------------------------------------------------";
            // 
            // labelFilesCount
            // 
            this.labelFilesCount.AutoSize = true;
            this.labelFilesCount.Location = new System.Drawing.Point(133, 86);
            this.labelFilesCount.Name = "labelFilesCount";
            this.labelFilesCount.Size = new System.Drawing.Size(18, 20);
            this.labelFilesCount.TabIndex = 6;
            this.labelFilesCount.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Поиск файлов - ";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 169);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(393, 27);
            this.progressBar1.TabIndex = 4;
            // 
            // labelProcessName
            // 
            this.labelProcessName.AutoSize = true;
            this.labelProcessName.Location = new System.Drawing.Point(8, 126);
            this.labelProcessName.Name = "labelProcessName";
            this.labelProcessName.Size = new System.Drawing.Size(320, 20);
            this.labelProcessName.TabIndex = 3;
            this.labelProcessName.Text = "Поиск файлов с запрещенными словами";
            // 
            // listBox2
            // 
            this.listBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.HorizontalScrollbar = true;
            this.listBox2.ItemHeight = 20;
            this.listBox2.Location = new System.Drawing.Point(413, 3);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(333, 407);
            this.listBox2.TabIndex = 2;
            // 
            // buttonStartPauseFind
            // 
            this.buttonStartPauseFind.Location = new System.Drawing.Point(8, 6);
            this.buttonStartPauseFind.Name = "buttonStartPauseFind";
            this.buttonStartPauseFind.Size = new System.Drawing.Size(184, 52);
            this.buttonStartPauseFind.TabIndex = 0;
            this.buttonStartPauseFind.Text = "Старт ";
            this.buttonStartPauseFind.UseVisualStyleBackColor = true;
            this.buttonStartPauseFind.Click += new System.EventHandler(this.buttonStartPauseFind_Click);
            // 
            // buttonStopFind
            // 
            this.buttonStopFind.Location = new System.Drawing.Point(223, 6);
            this.buttonStopFind.Name = "buttonStopFind";
            this.buttonStopFind.Size = new System.Drawing.Size(184, 52);
            this.buttonStopFind.TabIndex = 1;
            this.buttonStopFind.Text = "Стоп";
            this.buttonStopFind.UseVisualStyleBackColor = true;
            this.buttonStopFind.Click += new System.EventHandler(this.buttonStopFind_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 326);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(188, 20);
            this.label12.TabIndex = 18;
            this.label12.Text = "Замена слов на ******* - ";
            // 
            // labelUpdatedFilesCount
            // 
            this.labelUpdatedFilesCount.AutoSize = true;
            this.labelUpdatedFilesCount.Location = new System.Drawing.Point(174, 326);
            this.labelUpdatedFilesCount.Name = "labelUpdatedFilesCount";
            this.labelUpdatedFilesCount.Size = new System.Drawing.Size(18, 20);
            this.labelUpdatedFilesCount.TabIndex = 19;
            this.labelUpdatedFilesCount.Text = "0";
            // 
            // progressBar3
            // 
            this.progressBar3.Location = new System.Drawing.Point(12, 349);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(393, 27);
            this.progressBar3.TabIndex = 20;
            // 
            // progressBarLoadWords
            // 
            this.progressBarLoadWords.Location = new System.Drawing.Point(231, 41);
            this.progressBarLoadWords.Name = "progressBarLoadWords";
            this.progressBarLoadWords.Size = new System.Drawing.Size(275, 14);
            this.progressBarLoadWords.TabIndex = 9;
            // 
            // labelLoadWord
            // 
            this.labelLoadWord.AutoSize = true;
            this.labelLoadWord.Location = new System.Drawing.Point(302, 38);
            this.labelLoadWord.Name = "labelLoadWord";
            this.labelLoadWord.Size = new System.Drawing.Size(138, 20);
            this.labelLoadWord.TabIndex = 10;
            this.labelLoadWord.Text = "слова загружены";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(757, 446);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Поисковик запрещенных слов";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.tabControl1.ResumeLayout(false);
            this.tabPageWords.ResumeLayout(false);
            this.tabPageWords.PerformLayout();
            this.tabPageFindWords.ResumeLayout(false);
            this.tabPageFindWords.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageWords;
        private System.Windows.Forms.Button buttonAddWord;
        private System.Windows.Forms.TextBox textBoxNewWord;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TabPage tabPageFindWords;
        private System.Windows.Forms.Button buttonLoadFromFile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonCearList;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonStopFind;
        private System.Windows.Forms.Button buttonStartPauseFind;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label labelProcessName;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelFilesCount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxFolderPath;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonChangeFolder;
        private System.Windows.Forms.Label labelCopiedFilesCount;
        private System.Windows.Forms.Label labelUpdatedFilesCount;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.ProgressBar progressBarLoadWords;
        private System.Windows.Forms.Label labelLoadWord;
    }
}

