﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using ForbiddenWordsFinder;


namespace ForbiddenWordsFinder
{
    public partial class Form1 : Form
    {
        public bool LoadFlag {  get; set; }//используется в загрузке списка слов

        Mutex mutex = new Mutex(false, "MyForbiddenWordsApplication");//контроль запуска одного приложения

        private WordsFinder wordsFinder;
        private 
        public Form1()
        {
            InitializeComponent();
            wordsFinder = new WordsFinder();
            wordsFinder.fform1 = this;
            label7.Text = "";
            textBoxFolderPath.Text = Directory.GetCurrentDirectory();
            progressBarLoadWords.Visible = false;
            labelLoadWord.Visible = false;
        }
        public void AddXXX(string add)
        {
            listBox2.Items.Add(add);
        }
        private void загрузитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void buttonLoadFromFile_Click(object sender, EventArgs e)
        {
            progressBarLoadWords.Value = 0;
            
            LoadFlag = true;
            OpenFileDialog op = new OpenFileDialog();
            op.InitialDirectory = Directory.GetCurrentDirectory();
            if (op.ShowDialog() == DialogResult.OK)
            {
                progressBarLoadWords.Visible = true;
                buttonStartPauseFind.Enabled = false;
                wordsFinder.LoadForbiddenWordsList(op.FileName);
                progressBarLoadWords.Maximum = wordsFinder.ListOfForbiddenWords.Count;
                Task task = Task.Run(() =>
                {

                    foreach (var item in wordsFinder.ListOfForbiddenWords)
                    {
                        if (LoadFlag)
                        {
                            listBox1.Invoke((MethodInvoker)delegate
                            {

                                if (item != "")
                                {
                                    listBox1.Items.Add(item);
                                    progressBarLoadWords.Value++;

                                }

                            });

                        }
                        else
                        {
                            break;
                        }

                    }
                    buttonStartPauseFind.Invoke((MethodInvoker)delegate
                    {
                        buttonStartPauseFind.Enabled = true;
                        progressBarLoadWords.Visible = false;
                        labelLoadWord.Visible = true;
                    });
                });

            }
            else 
            {
                labelLoadWord.Visible = false;
            }
            

        }

        private void buttonCearList_Click(object sender, EventArgs e)
        {
            
            Task task = (Task)Task.Run(() =>
            {
                LoadFlag = false;
                wordsFinder.ClearList();
                listBox1.Items.Clear();
            });
            
        }

        private void buttonAddWord_Click(object sender, EventArgs e)
        {
            if (wordsFinder.AddWordToForbiddenWords(textBoxNewWord.Text))
            {
                listBox1.Items.Add(textBoxNewWord.Text);
            }
            
        }

        private async void buttonStartPauseFind_Click(object sender, EventArgs e)
        {

            if (!wordsFinder.flagMainFindUpdateOperationIsRun)
            {
                wordsFinder = new WordsFinder();
                //заполняю список запрещенных слов
                {
                    listBox1.Invoke((MethodInvoker)delegate {
                        foreach (var item in listBox1.Items)
                        {
                            lock (wordsFinder.lockObject)
                            {
                                wordsFinder.ListOfForbiddenWords.Add(item as string);
                            }
                        }
                    });

                }
                buttonChangeFolder.Enabled = true;
                label4.ForeColor = Color.Black;
                labelFilesCount.ForeColor = Color.Black;
                labelProcessName.ForeColor = Color.Black;
                label7.ForeColor = Color.Black;
                label9.ForeColor = Color.Black;
                labelCopiedFilesCount.ForeColor = Color.Black;
                labelUpdatedFilesCount.ForeColor = Color.Black;
                label12.ForeColor = Color.Black;
                progressBar1.Value = 0;
                progressBar2.Value = 0;
                progressBar3.Value = 0;
                buttonChangeFolder.Enabled = false;
                buttonStartPauseFind.Text = "Пауза";
                listBox2.Items.Clear();
                wordsFinder.flagMainFindUpdateOperationIsRun = true;
                progressBar1.Minimum = 0;
                //создаю список всех найденных файлов для поиска слов из списка
                Task.Run(() => { wordsFinder.SearchFilesInComputer(); });
                Task task1 = Task.Run(() =>
                {
                    
                    
                    while (true)
                    {
                        if (!wordsFinder.flagMainFindUpdateOperationIsRun)
                        {//нажат стоп
                            break;
                        }
                        Thread.Sleep(500);//чтобы сильно часто не обновлялось
                        
                        labelFilesCount.Invoke((MethodInvoker)delegate {
                            labelFilesCount.Text = wordsFinder.filesCount.ToString();
                        });


                        if (!wordsFinder.FlagSearchFilesInComputerIsRun && wordsFinder.TaskCount==0)
                        {//создание списка  файлов завершилось
                            if (wordsFinder.flagMainFindUpdateOperationIsRun)
                            {
                                labelFilesCount.Invoke((MethodInvoker)delegate {
                                    labelFilesCount.Text = $"завершено({wordsFinder.ListOfAllFiles.Count}шт)";
                                });
                                label4.ForeColor = Color.DarkGreen;
                                labelFilesCount.ForeColor = Color.DarkGreen; 
                            }
                            
                            break;
                        }
                       
                       
                    }

                    //запуск второго процесса
                    if (wordsFinder.flagMainFindUpdateOperationIsRun)
                    {
                        //MessageBox.Show("запускаю поиск файлов");
                        Task.Run(() => { wordsFinder.SearchFilesWithForbiddenWords(); });
                        Task task2 = Task.Run(() =>
                        {
                            progressBar1.Invoke((MethodInvoker)delegate {
                                progressBar1.Maximum = wordsFinder.ListOfAllFiles.Count;
                            });   
                            while (true)
                            {
                                progressBar2.Invoke((MethodInvoker)delegate
                                {
                                    while (progressBar1.Maximum < wordsFinder.CurrentFileInOperations)
                                    {//жду пока в progressBar2 запишется максимальное значение
                                        Thread.Sleep(300);
                                    }
                                    progressBar1.Value = wordsFinder.CurrentFileInOperations;
                                });



                                if (!wordsFinder.flagMainFindUpdateOperationIsRun)
                                {//нажат стоп
                                    break;
                                }



                                label7.Invoke((MethodInvoker)delegate {
                                    
                                    label7.Text = $"обработано {wordsFinder.CurrentFileInOperations-wordsFinder.TaskCount} штук;" +
                                        $" найдено {wordsFinder.ListOfFilesWithSearchedWords.Count} файлов";
                                });

                                Thread.Sleep(600);
                                if (!wordsFinder.FlagSearchFilesWithForbiddenWords)
                                {//поиск файлов с запрещенными словами завершен 
                                    label7.Invoke((MethodInvoker)delegate
                                    {
                                        progressBar1.Value = progressBar1.Maximum;
                                        label7.Text = $"обработано {wordsFinder.ListOfAllFiles.Count} штук; " +
                                        $"найдено {wordsFinder.ListOfFilesWithSearchedWords.Count} файлов";
                                        label7.ForeColor = Color.DarkGreen;
                                        labelProcessName.ForeColor = Color.DarkGreen;
                                    });
                                    break;
                                }
                            }

                            //запускаю 3 процесс  - копирую файлы с найденными словами
                            Task.Run(() => { wordsFinder.CopySelectedFiles(textBoxFolderPath.Text); });
                            //MessageBox.Show("asfdra");
                            Task task3 = Task.Run(() =>
                            {
                                progressBar2.Invoke((MethodInvoker)delegate
                                {
                                    progressBar2.Maximum = wordsFinder.ListOfFilesWithSearchedWords.Count;
                                });
                                while (true)
                                {
                                    progressBar2.Invoke((MethodInvoker)delegate
                                    {
                                        while (progressBar2.Maximum < wordsFinder.CurrentFileInOperations)
                                        {//жду пока в progressBar2 запишется максимальное значение
                                            Thread.Sleep(300);
                                        }
                                        progressBar2.Value = wordsFinder.CurrentFileInOperations;
                                    });

                                    if (!wordsFinder.flagMainFindUpdateOperationIsRun)
                                    {//нажат стоп
                                        break;
                                    }
                                    labelCopiedFilesCount.Invoke((MethodInvoker)delegate {
                                        labelCopiedFilesCount.Text = wordsFinder.CurrentFileInOperations.ToString();
                                    });
                                    Thread.Sleep(600);

                                    if (!wordsFinder.FlagCopySelectedFilesIsRun)
                                    {//копирование завершено
                                        labelCopiedFilesCount.Invoke((MethodInvoker)delegate
                                        {
                                            progressBar2.Value = progressBar2.Maximum;
                                            labelCopiedFilesCount.Text = $"завершено({wordsFinder.ListOfFilesWithSearchedWords.Count}шт)";
                                            labelCopiedFilesCount.ForeColor = Color.DarkGreen;
                                            label9.ForeColor = Color.DarkGreen;
                                        });
                                        break;
                                    }
                                }

                                //запускаю 4 процесс - создаю новый файл с содержимым оригинального файла,
                                //в котором запрещенные слова заменены на 7 повторяющихся звезд(*******).
                                Task updateFiles = Task.Run(() => {
                                    wordsFinder.UpdateSelectedFiles(textBoxFolderPath.Text);
                                    //wordsFinder.flagMainFindUpdateOperationIsRun = false;

                                });

                                //отображение на форме
                                Task task4 = Task.Run(() => {
                                    progressBar3.Invoke((MethodInvoker)delegate
                                    {
                                        progressBar3.Maximum = wordsFinder.ListOfCopiedFilesWithSearchedWords.Count;
                                    });
                                    while (true)
                                    {
                                        progressBar3.Invoke((MethodInvoker)delegate
                                        {
                                            while (progressBar3.Maximum < wordsFinder.CurrentFileInOperations)
                                            {//жду пока в progressBar2 запишется максимальное значение
                                                Thread.Sleep(300);
                                            }
                                            progressBar3.Value = wordsFinder.CurrentFileInOperations;
                                        });

                                        if (!wordsFinder.flagMainFindUpdateOperationIsRun)
                                        {//нажат стоп
                                            break;
                                        }
                                        labelCopiedFilesCount.Invoke((MethodInvoker)delegate {
                                            labelUpdatedFilesCount.Text = wordsFinder.CurrentFileInOperations.ToString();
                                        });
                                        Thread.Sleep(600);

                                        if (!wordsFinder.FlagUpdateSelectedFilesIsRun)
                                        {//копирование завершено
                                            labelUpdatedFilesCount.Invoke((MethodInvoker)delegate
                                            {
                                                progressBar3.Value = progressBar3.Maximum;
                                                labelUpdatedFilesCount.Text = $"завершено({wordsFinder.ListOfCopiedFilesWithSearchedWords.Count}шт)";
                                                labelUpdatedFilesCount.ForeColor = Color.DarkGreen;
                                                label12.ForeColor = Color.DarkGreen;
                                            });
                                            break;
                                        }
                                    }
                                });


                                Task.WaitAll(updateFiles, task4);

                                listBox2.Items.Add($"wordsFinder.ListOfAllFiles.Count = {wordsFinder.ListOfAllFiles.Count}");
                                listBox2.Items.Add($"wordsFinder.ListOfFilesWithSearchedWords.Count = {wordsFinder.ListOfFilesWithSearchedWords.Count}");
                                listBox2.Items.Add($"wordsFinder.ListOfCopiedFilesWithSearchedWords.Count = {wordsFinder.ListOfCopiedFilesWithSearchedWords.Count}");
                                listBox2.Items.Add($"wordsFinder.ListOfUpdatedFilesWithSearchedWords.Count = {wordsFinder.ListOfUpdatedFilesWithSearchedWords.Count}");
                                string dir = textBoxFolderPath.Text;
                                wordsFinder.MakeReport($"{dir}\\report.txt");

                                buttonStartPauseFind.Invoke((MethodInvoker)delegate
                                {
                                    buttonStartPauseFind.Text = "Старт";
                                });
                                lock (wordsFinder.lockObject)
                                {
                                    wordsFinder.flagMainFindUpdateOperationIsRun = false;
                                }
                                Task.Run(() =>
                                {
                                    listBox2.Invoke((MethodInvoker)delegate
                                    {
                                        foreach (var line in wordsFinder.report)
                                        {
                                            listBox2.Items.Add(line);
                                        }
                                    });

                                });
                                MessageBox.Show("Задание завершено");




                            });


                        });
                    }
                      

                });
            }
            else
            {
                if (wordsFinder.flagMainFindUpdateOperationIsPaused)
                {
                    wordsFinder.flagMainFindUpdateOperationIsPaused = false;
                    buttonStartPauseFind.Text = "Пауза";
                    buttonChangeFolder.Enabled = false;
                }
                else
                {
                    wordsFinder.flagMainFindUpdateOperationIsPaused = true;
                    buttonStartPauseFind.Text = "Продолжить";
                    if (!wordsFinder.FlagCopySelectedFilesIsRun && 
                        !wordsFinder.FlagUpdateSelectedFilesIsRun)//добавить что не идет замена символов
                    {
                        buttonChangeFolder.Enabled = true;
                    }
                }
            }

            
            
            
        }

        private void buttonStopFind_Click(object sender, EventArgs e)
        {
            wordsFinder.flagMainFindUpdateOperationIsRun = false;
            if (wordsFinder.FlagSearchFilesWithForbiddenWords)
            {
                buttonStartPauseFind.Enabled = false;
            }
            Task.Run(() => 
            {    
                //жду пока завершатся потоки поиска слов в файлах
                if (wordsFinder.FlagSearchFilesWithForbiddenWords)
                {
                    while (wordsFinder.FlagSearchFilesWithForbiddenWords)
                    {
                        Thread.Sleep(50);
                    }
                }
                wordsFinder = new WordsFinder();
                //заполняю список запрещенных слов
                {
                    listBox1.Invoke((MethodInvoker)delegate {
                        foreach (var item in listBox1.Items)
                        {
                            lock (wordsFinder.lockObject)
                            {
                                wordsFinder.ListOfForbiddenWords.Add(item as string);
                            }
                        }
                    });
                    
                }
                buttonStartPauseFind.Invoke((MethodInvoker)delegate { 
                    buttonStartPauseFind.Enabled = true;
                    buttonChangeFolder.Enabled = true;
                    buttonStartPauseFind.Text = "Старт";
                    labelFilesCount.Text = "0";
                    labelProcessName.Text = "Поиск файлов с запрещенными словами";
                    label7.Text = "";
                    listBox2.Items.Clear();
                    progressBar1.Value = 0;
                    progressBar2.Value = 0;
                    progressBar3.Value = 0;
                    label4.ForeColor = Color.Black;
                    labelFilesCount.ForeColor = Color.Black;
                    labelProcessName.ForeColor = Color.Black;
                    label7.ForeColor = Color.Black;
                    label9.ForeColor = Color.Black;
                    labelCopiedFilesCount.ForeColor = Color.Black;
                    labelUpdatedFilesCount.ForeColor = Color.Black;
                    label12.ForeColor = Color.Black;
                });
            });
            
            
        }

        private void buttonChangeFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fol = new FolderBrowserDialog();
            if (fol.ShowDialog() == DialogResult.OK)
            {
                textBoxFolderPath.Text = fol.SelectedPath;
            }
            
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            listBox2.Width = this.Width - 445;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //контроль запуска одного приложения
            if (!mutex.WaitOne(500, false))
            {
                MessageBox.Show("Приложение уже запущенно", "Ошибка");
                Close();
            }
        }
    }
}
