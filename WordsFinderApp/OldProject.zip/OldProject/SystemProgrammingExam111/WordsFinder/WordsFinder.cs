﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Threading;
using System.Threading.Tasks;
//using System.Windows.Forms;

namespace WordsFinderLibrary
{
    public class WordsFinder
    {
        //public Form1 fform1;
        public object lockObject;

        /// <summary>
        /// в этот каталог копируются файлы, и в него сохраняются измененные файлы
        /// </summary>
        public string PathForCopyUpdateFolder { get; set; } 

        public List<string> ListOfForbiddenWords { get; set; }//список слов которые будем искать

        /// <summary>
        /// string - имя файла в котором есть искомые слова
        /// FilesPathRecord - имя скопированного файла и имя измененного файла
        /// </summary>
        public Dictionary<string, FilesPathRecord> DictionaryOriginCopiedUpdatedFiles { get; set; }
        public List<string> ListOfAllFiles { get; set; } //список всех найденных файлов
        /// <summary>
        /// флаг работы всего поцесса поиска
        /// </summary>
        public bool flagMainFindUpdateOperationIsRun = false;//==true - поиск идет 
        public bool flagMainFindUpdateOperationIsPaused = false;//==true - поиск на паузе



        public bool FlagSearchFilesInComputerFinished { get; set; }//индикатор что SearchFilesInComputer() отработал
        public bool FlagSearchFilesWithForbiddenWordFinished { get; set; }//индикатор что SearchFilesWithForbiddenWords() отработал
        public bool FlagCopySelectedFilesFinished { get; set; }//индикатор работы метода CopySelectedFiles(string folderPath)
        public bool FlagUpdateSelectedFilesFinished { get; set; }//индикатор работы метода UpdateSelectedFiles(string folderPath)

        public Dictionary<string, int> Top10words { get; set; } //топ 10  самых популярных запрещенных слов
        public KeyValuePair<string, int>[] Top10wordsArray { get; set; } //топ 10  самых популярных запрещенных слов

        public Dictionary<string, int> DictionaryOFUpdatedFilesAndUpdatesCount { get; set; } //словарь файл - колличество в нем замен

        /// <summary>
        /// колличество запущенных задач
        /// </summary>
        public int TaskCount { get; set; }

        

        /// <summary>
        /// хранит в себе количество названий файлов которые записаны в ListOfAllFiles
        /// </summary>
        ///public int filesCount = 0;

        /// <summary>
        /// текущий номер(i) файла из массива всех файлов 
        /// в цикле поиска запрещенных слов
        /// </summary>
        public int CurrentFileInOperations { get; set; }

        private List<Task> Tasks { get; set; }

        /// <summary>
        /// отчет по проделанной работе
        /// </summary>
        public List<string> report { get; set; }

        public WordsFinder()
        {
            
            ListOfForbiddenWords = new List<string>();
            lockObject = new object();
            //ListOfFilesWithSearchedWords = new List<string>();
            DictionaryOriginCopiedUpdatedFiles = new Dictionary<string, FilesPathRecord>();
            //ListOfCopiedFilesWithSearchedWords = new List<string>();
            ListOfAllFiles = new List<string>();
            FlagSearchFilesInComputerFinished = false;
            FlagSearchFilesWithForbiddenWordFinished = false;
            FlagCopySelectedFilesFinished = false;
            FlagUpdateSelectedFilesFinished = false;
            TaskCount = 0;
            //удаляю лог если он есть
            if (File.Exists(Directory.GetCurrentDirectory() + "\\wordsFinder.log"))
            {
                File.Delete(Directory.GetCurrentDirectory() + "\\wordsFinder.log");
            }
            
            
        }

        /// <summary>
        /// Загружает из файла список запрещенных слов  
        /// </summary>
        /// <param name="path"></param>
        /// <returns>true - если загрузка прошла удачно, false - если нет</returns>
        public bool LoadForbiddenWordsList(string path)
        {
            try
            {
                string text = File.ReadAllText(path);
                lock (lockObject)
                {
                    ListOfForbiddenWords = text.Split(' ', '\n', (char)13).ToList();
                }
                return true;
            }
            catch (Exception ex)
            {
                //MessageBox.Show($"не получилось загрузить файл - {ex}");
                return false;
            }
        }

        /// <summary>
        /// очищает список запрещенных слов
        /// </summary>
        public void ClearListOfForbiddenWords()
        {
            lock (lockObject)
            {
                ListOfForbiddenWords = new List<string>();
            }
        }

        /// <summary>
        /// добавляет слово в список запрещеных слов
        /// </summary>
        /// <param name="word">слово которое нужно добавить</param>
        /// <returns>true - добавлено; false - не добавлено</returns>
        public bool AddWordToForbiddenWords(string word)
        {
            lock (lockObject)
            {
                if (ListOfForbiddenWords.Contains(word))
                {
                    return false;
                }
                ListOfForbiddenWords.Add(word);
                return true;
            }

        }


        /// <summary>
        /// записывает в ListOfAllFiles все файлы(на компьютере) 
        /// переменная filesCount отображает текущее колличество посчитанных файлов
        /// </summary>
        public void SearchFilesInComputer(string path = null)
        {
            
            if (path == null)
            {
                var drives = DriveInfo.GetDrives();
                foreach (var drive in drives)
                {
                    //перебираю диски которые доступны
                    if (drive.IsReady)
                    {
                        //if (drive.Name == "C:\\")//|| drive.Name == "G:\\")
                        //    continue;

                        TaskCount++;
                        FolderHandling(drive.RootDirectory.ToString());

                    }

                }
            }
            else
            {
                TaskCount++;
                FolderHandling(path);
                

            }
            while (TaskCount != 0)//жду пока отработают все потоки поиска файлов
            {}
            FlagSearchFilesInComputerFinished = true;

        }

        /// <summary>
        /// ищет все файлы(к которым есть доступ) в пути path и добавляет их в ListOfAllFiles
        /// </summary>
        /// <param name="path"></param>
        public void FolderHandling(string path)
        {


            //перебираю  все файлы в данной папке
            string[] files;
            try
            {
                files = Directory.GetFiles(path);
            }
            catch (UnauthorizedAccessException)
            {//нет доступа к папке

                lock (lockObject)
                {
                    TaskCount--;                    
                }
                return;
            }
            catch (Exception ex)
            {
                File.AppendAllText(Directory.GetCurrentDirectory() + "\\wordsFinder.log", $"FolderHandling({path}) Directory.GetFiles(path), type Exception - {ex}\n");
                lock (lockObject)
                {
                    TaskCount--;
                }
                return;
            }
            foreach (var file in files)
            {
                
                if (!flagMainFindUpdateOperationIsRun)
                {
                    return;

                }
                while (flagMainFindUpdateOperationIsPaused)
                {
                    Thread.Sleep(2000);
                    if (!flagMainFindUpdateOperationIsRun)
                    {
                        return;

                    }
                }
                //добавляю файлы в список
                lock (lockObject)
                {
                    //проверка файла на размер - если большой не добавляю - проблемы с открытием
                    long size = (((new FileInfo(file)).Length)/1024)/1024;
                    if (size < 500)
                    {
                        ListOfAllFiles.Add(file);
                        filesCount++;
                    }
                    else 
                    {
                        File.AppendAllText(Directory.GetCurrentDirectory() + "\\wordsFinder.log",
                            $"файл {file} пропущен, его размер - {size} мб\n");
                    }
                    
                }
            }


            //перебираю все папки в данной папке
            string[] folders;
            try
            {
                folders = Directory.GetDirectories(path);
            }
            catch (UnauthorizedAccessException)//пропускаю папки к которым нет доступа
            {
                lock (lockObject)
                {
                    TaskCount--;
                }
                return;
            }
            catch (Exception ex)
            {
                File.AppendAllText(Directory.GetCurrentDirectory() + "\\wordsFinder.log", $"FolderHandling({path}) Directory.GetDirectories(path),  - {ex}\n");
                lock (lockObject)
                {
                    TaskCount--;
                }
                return;
            }
            if (folders.Length > 0)
            {
                foreach (var folder in folders)
                {
                    if (!flagMainFindUpdateOperationIsRun)
                    {
                        return;

                    }
                    while (flagMainFindUpdateOperationIsPaused)
                    {
                        Thread.Sleep(2000);
                        if (!flagMainFindUpdateOperationIsRun)
                        {
                            return;

                        }
                    }
                    lock (lockObject)
                    {
                        TaskCount++;
                    }
                    Task task = Task.Run(() =>
                    {
                        FolderHandling(folder.ToString());
                    });
                    //Tasks.Add(task);
                }
            }
            lock (lockObject)
            {
                TaskCount--;
            }
        }


        /// <summary>
        /// перебирает все найденные файлы из  ListOfAllFiles 
        /// и файлы с запрещенными словами добавляю в  FilesWithSearchedWords
        /// отслеживание прогресса CurrentFileInOperations
        /// </summary>
        public void SearchFilesWithForbiddenWords()
        {
            
            bool flagStop = false;
            TaskCount = 0;
            Tasks = new List<Task>();

            for (int i = 0; i < ListOfAllFiles.Count; i++)
            {//перебираю все найденные файлы

                if (!flagMainFindUpdateOperationIsRun)
                {
                    flagStop = true;
                }
                while (flagMainFindUpdateOperationIsPaused)
                {
                    Thread.Sleep(2000);
                    if (!flagMainFindUpdateOperationIsRun)
                    {
                        flagStop = true;
                    }
                    if (flagStop)
                    {
                        break;
                    }
                }

                while (TaskCount >= Environment.ProcessorCount)
                {
                    
                }

                CurrentFileInOperations = i + 1;

                string file = ListOfAllFiles[i];

                lock (lockObject)
                {
                    TaskCount++;
                }

                Task task = Task.Run(() =>
                {
                    if (!flagMainFindUpdateOperationIsRun)
                    {
                        lock (lockObject)
                        {
                            TaskCount--;
                        }
                        return;
                    }
                    if (ContainsListWords(file))
                    {//найдены слова в файле 
                        lock (lockObject)
                        {
                            DictionaryOriginCopiedUpdatedFiles[file] = 
                                new FilesPathRecord() { copiedPath = "", updatedPath = "" };
                        }
                    }
                    lock (lockObject)
                    {
                        TaskCount--;
                    }
                });
                Tasks.Add(task);
                if (flagStop)
                {
                    i = ListOfAllFiles.Count + 1;
                }
            }
            Task.WaitAll(Tasks.ToArray());
            FlagSearchFilesWithForbiddenWordFinished = true;
        }

        /// <summary>
        /// определяет есть ли в файле filePath слова из списка ForbiddenWords
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns>true - найдены слова; false - слова не найдены </returns>
        public bool ContainsListWords(string filePath)
        {
            string text;
            try
            {
                text = File.ReadAllText(filePath);
            }
            catch (UnauthorizedAccessException)//нет доступа к файлу
            {
                return false;
            }
            catch (ArgumentNullException)//нет доступа к файлу
            {
                return false;
            }
            catch (IOException)//нет доступа к файлу
            {
                return false;
            }
            foreach (var word in ListOfForbiddenWords)
            {

                if (text.Contains(word))
                {

                    return true;
                }

            }

            return false;
        }

        /// <summary>
        /// копирую файлы содержащие запрещенные слова в папку folderPath
        /// </summary>
        /// <param name="folderPath"> папка в которую будут копироваться файлы, null - в текущей папке создается папка Copies</param>
        public void CopySelectedFiles(string folderPath = null)
        {
            if (folderPath == null)
            {//пытаюсь создать в текущей папке папку Copies 
                PathForCopyUpdateFolder = Directory.GetCurrentDirectory() + "\\Copies";
                if (!Directory.Exists(PathForCopyUpdateFolder))
                {//если папк нет создаю ее
                    try
                    {
                        Directory.CreateDirectory(PathForCopyUpdateFolder);
                    }
                    catch (Exception ex)
                    {
                        File.AppendAllText(Directory.GetCurrentDirectory() + "\\wordsFinder.log", 
                            $"CopySelectedFiles() - пытаюсь создать папку: {PathForCopyUpdateFolder} , type Exception - {ex}\n");
                        PathForCopyUpdateFolder = Directory.GetCurrentDirectory();
                    }
                }
            }
            CurrentFileInOperations = 0;//индикатор текущего положения копирования файлов
            bool flagStop = false;
            TaskCount = 0;
            List<Task> tasks = new List<Task>();
            foreach(var item in DictionaryOriginCopiedUpdatedFiles)
            {//перебираю список файлов
                string fileOrigin = item.Key;

                if (!flagMainFindUpdateOperationIsRun)
                {
                    flagStop = true;
                    //return;
                }
                while (flagMainFindUpdateOperationIsPaused)
                {
                    Thread.Sleep(2000);
                    if (!flagMainFindUpdateOperationIsRun)
                    {
                        flagStop = true;
                        //return;
                    }
                    if (flagStop)
                    {
                        break;
                    }
                }

                while (TaskCount >= Environment.ProcessorCount)
                {
                    //Thread.Sleep(50);
                }


                lock (lockObject)
                {
                    TaskCount++;
                }
                string indexFilePath = item.Key;//параметр текущего файла для потока
                Task task = Task.Run(() =>
                {

                    string newFile = GetNewFileName(fileOrigin, PathForCopyUpdateFolder);
                    try
                    {
                        File.Copy(fileOrigin, newFile);
                        //добавляю в список скопированных файлов файл
                        lock (lockObject)
                        {

                            //DictionaryOriginCopiedUpdatedFiles[item.Key].SetCopiedPath(newFile);
                            DictionaryOriginCopiedUpdatedFiles[indexFilePath] = new FilesPathRecord() { copiedPath = newFile, updatedPath = "" };
                        }
                    }
                    catch (Exception ex)
                    {//скопировать не уалось
                        File.AppendAllText(Directory.GetCurrentDirectory() + "\\wordsFinder.log",
                            $"CopySelectedFiles() - пытаюсь скопировать файл: {fileOrigin} в место {newFile} ,  {ex}\n");
                        //убираю запись в DictionaryOriginCopiedUpdatedFiles
                        lock (lockObject)
                        {
                            DictionaryOriginCopiedUpdatedFiles.Remove(indexFilePath);
                        }
                        
                    }

                    lock (lockObject)
                    {
                        CurrentFileInOperations++;
                        TaskCount--;
                    }
                });
                tasks.Add(task);
                if (flagStop)
                {
                    //i = ListOfFilesWithSearchedWords.Count + 1;
                    break;
                }
            }

            Task.WaitAll(tasks.ToArray());

            FlagCopySelectedFilesFinished = true;
        }

        /// <summary>
        /// проверяет нет ли по указанному адресу такого файла.
        /// если есть - то добавляет к имени файла надпись "_copy*",  * - номер копии
        /// </summary>
        /// <param name="oldFileName"></param>
        /// <param name="folderPath"></param>
        /// <returns>уникальное имя для файла</returns>
        private string GetNewFileName(string oldFileName, string folderPath)
        {
            var splits = oldFileName.Split('\\');
            string fileName = splits[splits.Length - 1];
            var splitFileName = fileName.Split('.');

            string newFile = $"{folderPath}\\{fileName}";
            //string newFile = $"{folderPath}\\Copies\\{fileName}";

            int index = 1;
            while (File.Exists(newFile))
            {
                if (splitFileName.Length == 2)
                {
                    newFile = $"{folderPath}\\{splitFileName[0]}_copy{index}.{splitFileName[1]}";
                    //newFile = $"{folderPath}\\Copies\\{splitFileName[0]}_copy{index}.{splitFileName[1]}";
                }
                else
                {
                    newFile = $"{folderPath}\\{splitFileName[0]}_copy{index}";
                    //newFile = $"{folderPath}\\Copies\\{splitFileName[0]}_copy{index}";
                }
                index++;
            }
            return newFile;

        }

        /// <summary>
        /// меняет запрещенные слова в файлах из ListOfFilesWithSearchedWords на "*******";  
        /// отслеживание прогресса CurrentFileInOperations
        /// </summary>
        public void UpdateSelectedFiles()
        {
            
            //подготавливаю топ10
            Top10words = new Dictionary<string, int>();
            Task ts = Task.Run(() => {
                foreach (string word in ListOfForbiddenWords)
                {
                    Top10words[word] = 0;
                }
            });


            //подготавливаю словарь файл - замены в файле
            DictionaryOFUpdatedFilesAndUpdatesCount = new Dictionary<string, int>();
            Task ts1 = Task.Run(() => {
                //foreach (string file in ListOfCopiedFilesWithSearchedWords)
                //{
                //    DictionaryOFUpdatedFilesAndUpdatesCount[file] = 0;
                //}
                foreach (var file in DictionaryOriginCopiedUpdatedFiles)
                {
                    DictionaryOFUpdatedFilesAndUpdatesCount[file.Value.copiedPath] = 0;
                }

            });

            Task.WaitAll(ts, ts1);

            bool flagStop = false;
            TaskCount = 0;
            CurrentFileInOperations = 0;
            List<Task> tasks = new List<Task>();
            //for (int i = 0; i < ListOfCopiedFilesWithSearchedWords.Count; i++)
            foreach(var item in DictionaryOriginCopiedUpdatedFiles)
            {//перебираю все файлы
                string fileToUpdate = item.Value.copiedPath;
                if (!flagMainFindUpdateOperationIsRun)
                {
                    flagStop = true;
                    //return;
                }
                while (flagMainFindUpdateOperationIsPaused)
                {
                    Thread.Sleep(2000);
                    if (!flagMainFindUpdateOperationIsRun)
                    {
                        flagStop = true;
                        //return;
                    }
                    if (flagStop)
                    {
                        break;
                    }
                }

                while (TaskCount >= Environment.ProcessorCount)
                {
                    //Thread.Sleep(50);
                }


                lock (lockObject)
                {
                    TaskCount++;
                }
                string indexFileName = item.Key;//сохраняю параметр для таска 
                Task task = Task.Run(() => {

                    string text;
                    string tempText;
                    text = File.ReadAllText(fileToUpdate);
                    for (int j = 0; j < ListOfForbiddenWords.Count; j++)
                    { //перебираю все слова

                        tempText = text.Replace(ListOfForbiddenWords[j], "*******");
                        if (!tempText.Equals(text))
                        {//произведена замена 
                            //записываю в статистику по слову
                            Top10words[ListOfForbiddenWords[j]] = Top10words[ListOfForbiddenWords[j]] + 1;
                            //записываю в статистику по файлу
                            DictionaryOFUpdatedFilesAndUpdatesCount[fileToUpdate] =
                                DictionaryOFUpdatedFilesAndUpdatesCount[fileToUpdate] + 1;
                        }
                        text = tempText;
                    }
                    string newFile;
                    while (true)//цикл для того чтобы гарантировать что название файла никто не занял
                    {
                        newFile = GetNewUpdatedFileName(fileToUpdate, PathForCopyUpdateFolder);
                        if (File.Exists(newFile))
                        {
                            fileToUpdate = newFile;
                            continue;
                        }
                        try
                        {
                            File.WriteAllText(newFile, text);
                            break;
                        }
                        catch (IOException)
                        {//нет доступа к файлу, его занял другой процесс
                            //пробую получить другое название
                            fileToUpdate = newFile;
                        }
                    }

                    //добавляю название измененного файла в словарь
                    //ListOfUpdatedFilesWithSearchedWords.Add(newFile);
                    string first = DictionaryOriginCopiedUpdatedFiles[indexFileName].copiedPath;
                    DictionaryOriginCopiedUpdatedFiles[indexFileName] =
                        new FilesPathRecord()
                        {
                            copiedPath = DictionaryOriginCopiedUpdatedFiles[indexFileName].copiedPath,
                            updatedPath = newFile
                        };
                    lock (lockObject)
                    {
                        CurrentFileInOperations++;
                        TaskCount--;
                    }
                });
                tasks.Add(task);
                if (flagStop)
                {
                    //i = ListOfCopiedFilesWithSearchedWords.Count + 1;
                    break;
                }
            }
            Task.WaitAll(tasks.ToArray());
            Top10wordsArray = Top10words.ToArray();
            //Array.Sort(Top10wordsArray, new SortForTop10Wods());
            FlagUpdateSelectedFilesFinished = true;
        }

        /// <summary>
        /// сортировщик для Top10wordsArray
        /// </summary>
        public class SortForTop10Wods : IComparer<KeyValuePair<string, int>>
        {
            public int Compare(KeyValuePair<string, int> x, KeyValuePair<string, int> y)
            {
                return (y.Value).CompareTo(x.Value);
            }
        }

        /// <summary>
        /// проверяет нет ли по указанному адресу такого файла.
        /// если есть - то добавляет к имени файла надпись "_updated*",  * - номер копии
        /// </summary>
        /// <param name="oldFileName"></param>
        /// <param name="folderPath"></param>
        /// <returns>уникальное имя для файла </returns>
        private string GetNewUpdatedFileName(string oldFileName, string folderPath)
        {
            var splits = oldFileName.Split('\\');
            string fileName = splits[splits.Length - 1];
            var splitFileName = fileName.Split('.');

            string newFile = $"{folderPath}\\{fileName}";
            //string newFile = $"{folderPath}\\Copies\\{fileName}";

            int index = 1;
            while (File.Exists(newFile))
            {
                if (splitFileName.Length == 2)
                {
                    newFile = $"{folderPath}\\{splitFileName[0]}_updated{index}.{splitFileName[1]}";
                    //newFile = $"{folderPath}\\Copies\\{splitFileName[0]}_updated{index}.{splitFileName[1]}";
                }
                else
                {
                    newFile = $"{folderPath}\\{splitFileName[0]}_updated{index}";
                    //newFile = $"{folderPath}\\Copies\\{splitFileName[0]}_updated{index}";
                }
                index++;
            }
            return newFile;

        }

        /// <summary>
        /// создает файл отчета и записывает его в файл по пути path
        /// </summary>
        /// <param name="path">путь/название файла куда сохранить отчет</param>
        public void MakeReport(string path)
        {
            Array.Sort(Top10wordsArray, new SortForTop10Wods());
            report = new List<string>();
            report.Add("\tТоп 10 самых популярных запрещенных слов:");

            for (int j = 0; j < Top10wordsArray.Length; j++)
            {
                if (j == 10)
                {
                    break;
                }
                report.Add($"{j + 1}) {Top10wordsArray[j].Key} - {Top10wordsArray[j].Value} раз");

            }
            report.Add($"");
            report.Add($"\tСписок обработанных файлов:");
            //for (int i = 0; i < ListOfFilesWithSearchedWords.Count; i++)
            //{
            //    ListOfFilesWithSearchedWords.Sort();
            //    ListOfCopiedFilesWithSearchedWords.Sort();
            //    ListOfUpdatedFilesWithSearchedWords.Sort();
            //    long size = (new FileInfo(ListOfFilesWithSearchedWords[i])).Length;
            //    report.Add($"{i + 1}. файл {ListOfFilesWithSearchedWords[i]}");
            //    report.Add($"\tразмер файла - {size / 1024} кБайт ({size} байт)");
            //    report.Add($"\tскопированый файл - {ListOfCopiedFilesWithSearchedWords[i]}");
            //    report.Add($"\tизмененый файл  - {ListOfUpdatedFilesWithSearchedWords[i]}");
            //    report.Add($"\tколичество замен - {DictionaryOFUpdatedFilesAndUpdatesCount[ListOfCopiedFilesWithSearchedWords[i]]} раз");
            //}
            int i = 1;
            foreach (var item in DictionaryOriginCopiedUpdatedFiles)
            {
                long size = (new FileInfo(item.Key)).Length;
                report.Add($"{i++}. файл {item.Key}");
                report.Add($"\tразмер файла - {size / 1024} кБайт ({size} байт)");
                report.Add($"\tскопированый файл - {item.Value.copiedPath}");
                report.Add($"\tизмененый файл  - {item.Value.updatedPath}");
                report.Add($"\tколичество замен - {DictionaryOFUpdatedFilesAndUpdatesCount[item.Value.copiedPath]} раз");
            }

            //записываю в файл
            File.WriteAllLines(path+"\\report.txt", report);

        }

        
        /// <summary>
        /// метод запускающий всю цепочку вызовов методов
        /// </summary>
        /// <param name="path">путь к папке где искать файлы(null - ищем во всем компьютере)</param>
        /// <param name="folderForFiles">путь к папке куда будут копироваться файлы(null - создается папка Copies в текущем каталоге)</param>
        public void CommonSearchCopyUpdateMethod(string path = null, string folderForFiles = null)
        {

            flagMainFindUpdateOperationIsRun = true;
            Console.WriteLine("SearchFilesInComputer starts");
            SearchFilesInComputer(path);
            Console.WriteLine("SearchFilesWithForbiddenWords starts");
            SearchFilesWithForbiddenWords();
            Console.WriteLine("CopySelectedFiles starts");
            CopySelectedFiles(folderForFiles);
            Console.WriteLine("UpdateSelectedFiles starts");
            UpdateSelectedFiles();
            Console.WriteLine("MakeReport starts");
            MakeReport(PathForCopyUpdateFolder);


        }


    }
    public struct FilesPathRecord
    {
        public string copiedPath;
        public string updatedPath;
    }
}
